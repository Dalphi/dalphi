valid1
